let mask = document.querySelector(".mask");
let fileDom = document.querySelector(".file");

mask.addEventListener("click", () => {
	plus.webview.currentWebview().close();
});

document.addEventListener('UniAppJSBridgeReady', () => {
	fileDom.addEventListener('change', (event) => {
		let file = fileDom.files[0];
		if(file.size > (1024*1024 * 10)) {
			plus.nativeUI.toast('单个文件请勿超过10M,请重新上传');
			return;
		}
		console.log('file:' + file);
		// let reader = new FileReader();
		// reader.onload = function(e){
		// 	var dataUrl = e.target.result
		// 	location.href = `callback?choosefile=${escape(dataUrl)}`;
		// 	setTimeout(()=>{
		// 		plus.webview.currentWebview().close();
		// 	},1000);
		// }
		// reader.readAsDataURL(file)
		
		// location.href = `callback?name=${escape(file.name)}&size=${escape(file.size)}&type=${escape(file.type)}&lastModified=${escape(file.lastModified)}&webkitRelativePath=${escape(file.webkitRelativePath)}`;
		location.href = `callback?name=${escape(file.name)}&size=${escape(file.size)}`;
		setTimeout(()=>{
			plus.webview.currentWebview().close();
		},1000);
		
	}, false);
});